package br.com.juquinha.api.controllers;

import org.springframework.web.bind.annotation.*;

import br.com.juquinha.api.models.Cliente;
import br.com.juquinha.api.repositories.IClienteRepository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("cliente")
public class ClienteController {
    private IClienteRepository repository;

    public ClienteController(IClienteRepository repository){
        this.repository = repository;
    }

    @GetMapping("")
    public List<Cliente> index(){
        List<Cliente> list = new ArrayList<>();
        list.add(new Cliente());
        return list;
    }

    @GetMapping("{id}")
    @PostMapping("")
    public ResponseEntity<Object> store() {
        return null;
    }
}
