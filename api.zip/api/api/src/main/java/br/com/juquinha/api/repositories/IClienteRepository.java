package br.com.juquinha.api.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import br.com.juquinha.api.models.Cliente;

@Repository
public interface IClienteRepository extends PagingAndSortingRepository<Cliente, Long> {
    @Query("select c from Cliente as c where c.nome like %:nome%")
    public List<Cliente> findByNome(String nome);
}
